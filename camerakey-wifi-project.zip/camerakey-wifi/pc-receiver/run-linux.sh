#!/usr/bin/env bash
# CameraKey receiver launcher for Ubuntu / Debian (works on Wayland and X11).
set -euo pipefail
cd "$(dirname "$0")"

# 1) /dev/uinput lets us create a virtual keyboard that works in EVERY app (also on Wayland).
if [[ ! -w /dev/uinput ]]; then
  echo "Need access to /dev/uinput (one-time per boot). Asking for sudo..."
  sudo modprobe uinput
  sudo chmod 0660 /dev/uinput
  sudo chgrp "$(id -gn)" /dev/uinput
fi

# 2) Python env
if [[ ! -d .venv ]]; then python3 -m venv .venv; fi
source .venv/bin/activate
python -m pip install --quiet --upgrade pip
python -m pip install --quiet -r requirements.txt

# 3) Token + run
if [[ -z "${CAMERAKEY_TOKEN:-}" ]]; then
  read -rp "Enter a shared token (type the same one in the phone app): " CAMERAKEY_TOKEN
  export CAMERAKEY_TOKEN
fi
if [[ "${1:-}" == "--selftest" ]]; then shift; python receiver.py --selftest "$@"; exit; fi
python receiver.py "$@"
