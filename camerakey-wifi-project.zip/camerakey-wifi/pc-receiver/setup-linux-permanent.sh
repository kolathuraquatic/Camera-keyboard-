#!/usr/bin/env bash
# Optional: make /dev/uinput access permanent (survives reboot). Log out and in afterwards.
set -euo pipefail
echo 'KERNEL=="uinput", MODE="0660", GROUP="input", OPTIONS+="static_node=uinput"' | sudo tee /etc/udev/rules.d/99-camerakey-uinput.rules >/dev/null
echo uinput | sudo tee /etc/modules-load.d/uinput.conf >/dev/null
sudo usermod -aG input "$USER"
sudo udevadm control --reload-rules && sudo udevadm trigger
echo "Done. Log out and log back in once, then run ./run-linux.sh"
