#!/usr/bin/env python3
"""CameraKey WiFi receiver.

Receives authenticated key-down/up events from the phone over the LAN and types them on this PC.

Backends (auto-selected):
  * uinput  (Linux, via python-evdev)  -> works on Wayland AND X11, in every app.  Needs access to /dev/uinput.
  * pynput  (Windows / macOS / Linux X11 only)
"""
import argparse
import asyncio
import json
import os
import socket
import sys
import time

import websockets

# ----------------------------------------------------------------------------- key name normalisation
ALIASES = {
    "RETURN": "ENTER", "ESCAPE": "ESC", "CONTROL": "CTRL", "SHIFT": "LSHIFT", "CTRL": "LCTRL", "ALT": "LALT",
    "CAPS": "CAPSLOCK", "BKSP": "BACKSPACE", "DEL": "DELETE", "PGUP": "PAGEUP", "PGDN": "PAGEDOWN",
}


def normalise(label: str) -> str:
    name = label.strip().upper()
    return ALIASES.get(name, name)


# ----------------------------------------------------------------------------- backends
class UInputBackend:
    name = "uinput"

    def __init__(self):
        from evdev import UInput, ecodes as e  # type: ignore
        self.e = e
        self.codes = self._build_map(e)
        self.ui = UInput(events={e.EV_KEY: sorted(set(self.codes.values()))}, name="CameraKey virtual keyboard")
        time.sleep(0.3)  # let the desktop notice the new device

    @staticmethod
    def _build_map(e):
        m = {}
        for ch in "ABCDEFGHIJKLMNOPQRSTUVWXYZ":
            m[ch] = getattr(e, "KEY_" + ch)
        for d in "0123456789":
            m[d] = getattr(e, "KEY_" + d)
        m.update({
            "`": e.KEY_GRAVE, "-": e.KEY_MINUS, "=": e.KEY_EQUAL, "[": e.KEY_LEFTBRACE, "]": e.KEY_RIGHTBRACE,
            "\\": e.KEY_BACKSLASH, ";": e.KEY_SEMICOLON, "'": e.KEY_APOSTROPHE, ",": e.KEY_COMMA,
            ".": e.KEY_DOT, "/": e.KEY_SLASH,
            "SPACE": e.KEY_SPACE, "ENTER": e.KEY_ENTER, "TAB": e.KEY_TAB, "BACKSPACE": e.KEY_BACKSPACE,
            "DELETE": e.KEY_DELETE, "ESC": e.KEY_ESC, "UP": e.KEY_UP, "DOWN": e.KEY_DOWN, "LEFT": e.KEY_LEFT,
            "RIGHT": e.KEY_RIGHT, "HOME": e.KEY_HOME, "END": e.KEY_END, "PAGEUP": e.KEY_PAGEUP,
            "PAGEDOWN": e.KEY_PAGEDOWN, "INSERT": e.KEY_INSERT, "CAPSLOCK": e.KEY_CAPSLOCK,
            "LSHIFT": e.KEY_LEFTSHIFT, "RSHIFT": e.KEY_RIGHTSHIFT, "LCTRL": e.KEY_LEFTCTRL,
            "RCTRL": e.KEY_RIGHTCTRL, "LALT": e.KEY_LEFTALT, "RALT": e.KEY_RIGHTALT,
        })
        for i in range(1, 13):
            m["F%d" % i] = getattr(e, "KEY_F%d" % i)
        return m

    def supports(self, label):
        return label in self.codes

    def press(self, label):
        self.ui.write(self.e.EV_KEY, self.codes[label], 1)
        self.ui.syn()

    def release(self, label):
        self.ui.write(self.e.EV_KEY, self.codes[label], 0)
        self.ui.syn()

    def close(self):
        try:
            self.ui.close()
        except Exception:
            pass


class PynputBackend:
    name = "pynput"

    def __init__(self):
        from pynput.keyboard import Controller, Key  # type: ignore
        self.kb = Controller()
        K = Key
        self.special = {
            "SPACE": K.space, "ENTER": K.enter, "TAB": K.tab, "BACKSPACE": K.backspace, "DELETE": K.delete,
            "ESC": K.esc, "UP": K.up, "DOWN": K.down, "LEFT": K.left, "RIGHT": K.right, "HOME": K.home,
            "END": K.end, "PAGEUP": K.page_up, "PAGEDOWN": K.page_down, "INSERT": K.insert,
            "CAPSLOCK": K.caps_lock, "LSHIFT": K.shift_l, "RSHIFT": K.shift_r, "LCTRL": K.ctrl_l,
            "RCTRL": K.ctrl_r, "LALT": K.alt_l, "RALT": K.alt_r,
        }
        for i in range(1, 13):
            self.special["F%d" % i] = getattr(K, "f%d" % i)

    def _key(self, label):
        if label in self.special:
            return self.special[label]
        if len(label) == 1:
            return label.lower() if label.isalpha() else label
        raise ValueError(label)

    def supports(self, label):
        try:
            self._key(label)
            return True
        except ValueError:
            return False

    def press(self, label):
        self.kb.press(self._key(label))

    def release(self, label):
        self.kb.release(self._key(label))

    def close(self):
        pass


def make_backend(preferred: str):
    errors = []
    order = ["uinput", "pynput"] if preferred == "auto" else [preferred]
    if sys.platform != "linux":
        order = ["pynput"]
    for name in order:
        try:
            backend = UInputBackend() if name == "uinput" else PynputBackend()
            return backend
        except Exception as exc:  # noqa: BLE001
            errors.append((name, exc))
    print("\nERROR: could not start any keyboard backend:", file=sys.stderr)
    for name, exc in errors:
        print(f"  - {name}: {type(exc).__name__}: {exc}", file=sys.stderr)
    if sys.platform == "linux":
        print("\nFix for Ubuntu/Wayland: run ./run-linux.sh (it grants access to /dev/uinput),"
              "\nor manually:  sudo modprobe uinput && sudo chmod 666 /dev/uinput", file=sys.stderr)
    raise SystemExit(3)


# ----------------------------------------------------------------------------- protocol logic
class KeyState:
    def __init__(self, backend):
        self.backend = backend
        self.held = set()

    def apply(self, label: str, down: bool):
        """Returns an error string or None."""
        label = normalise(label)
        if not self.backend.supports(label):
            return f"unsupported key: {label}"
        if down and label not in self.held:
            self.backend.press(label)
            self.held.add(label)
            print(f"DOWN {label}", flush=True)
        elif not down and label in self.held:
            self.backend.release(label)
            self.held.discard(label)
            print(f"UP   {label}", flush=True)
        return None

    def release_all(self):
        for label in list(self.held):
            try:
                self.backend.release(label)
            except Exception:  # noqa: BLE001
                pass
        self.held.clear()


async def handle_client(websocket, state: KeyState, token: str):
    authenticated = False
    peer = getattr(websocket, "remote_address", "unknown")
    print(f"[+] Client connected: {peer}", flush=True)
    try:
        async for raw in websocket:
            try:
                message = json.loads(raw)
            except json.JSONDecodeError:
                await websocket.send(json.dumps({"error": "invalid_json"}))
                continue
            if not authenticated:
                if message.get("type") == "auth" and message.get("token") == token:
                    authenticated = True
                    await websocket.send(json.dumps({"status": "authenticated", "backend": state.backend.name}))
                    print(f"[+] Authenticated: {peer}", flush=True)
                else:
                    await websocket.send(json.dumps({"error": "authentication_failed"}))
                    await websocket.close(code=4001, reason="Authentication failed")
                    break
                continue
            if message.get("type") == "key":
                label = str(message.get("key", "")).strip()
                down = message.get("down")
                if not label or len(label) > 12 or not isinstance(down, bool):
                    continue
                err = state.apply(label, down)
                if err:
                    print("   ", err, flush=True)
                    await websocket.send(json.dumps({"error": err}))
            elif message.get("type") == "release_all":
                state.release_all()
    except websockets.ConnectionClosed:
        pass
    finally:
        state.release_all()  # never leave a key stuck if the phone drops
        print(f"[-] Client disconnected: {peer}", flush=True)


def local_ip() -> str:
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        sock.connect(("8.8.8.8", 80))
        return sock.getsockname()[0]
    except OSError:
        return "127.0.0.1"
    finally:
        sock.close()


async def main():
    parser = argparse.ArgumentParser(description="CameraKey WiFi PC keyboard receiver")
    parser.add_argument("--host", default="0.0.0.0")
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--token", default=os.environ.get("CAMERAKEY_TOKEN"))
    parser.add_argument("--backend", choices=["auto", "uinput", "pynput"], default="auto")
    parser.add_argument("--selftest", action="store_true",
                        help="after 5 seconds type the letters 'w' 'o' 'r' 'k' to prove the PC side works, then exit")
    args = parser.parse_args()

    backend = make_backend(args.backend)
    state = KeyState(backend)
    print(f"Keyboard backend: {backend.name}")
    if backend.name == "pynput" and sys.platform == "linux":
        print("WARNING: pynput only reaches X11/XWayland apps. On Ubuntu's default Wayland session most apps will NOT "
              "receive keys. Use the uinput backend (see README).")

    if args.selftest:
        print("SELF-TEST: click into a text editor now... typing 'work' in 5 seconds")
        await asyncio.sleep(5)
        for ch in "WORK":
            state.apply(ch, True)
            await asyncio.sleep(0.05)
            state.apply(ch, False)
            await asyncio.sleep(0.1)
        backend.close()
        return

    if not args.token:
        print("ERROR: set CAMERAKEY_TOKEN or pass --token.", file=sys.stderr)
        raise SystemExit(2)

    print("CameraKey WiFi receiver")
    print(f"Listening: ws://{local_ip()}:{args.port}")
    print("Enter this IP and the same shared token in the Android app. Ctrl+C to stop.", flush=True)
    async with websockets.serve(lambda ws, path=None: handle_client(ws, state, args.token),
                                args.host, args.port, ping_interval=20, ping_timeout=20, max_size=4096):
        await asyncio.Future()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\nReceiver stopped.")
