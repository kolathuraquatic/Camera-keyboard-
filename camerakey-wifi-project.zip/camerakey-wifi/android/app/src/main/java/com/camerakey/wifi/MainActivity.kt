package com.camerakey.wifi

import android.Manifest
import android.app.AlertDialog
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.InputFilter
import android.util.Size
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.java_websocket.client.WebSocketClient
import org.java_websocket.handshake.ServerHandshake
import org.json.JSONObject
import java.net.URI
import java.util.concurrent.Executors

/**
 * Workflow:
 *  1. Connect to the PC, press "Test W" -> a "w" must appear on the PC (proves the network + PC side).
 *  2. Point the phone at the keyboard. "Scan" draws an outline around the keyboard and every key, live.
 *  3. Keep hands away, press "Lock + baseline" (3 s countdown). Layout and the clean picture are frozen.
 *  4. "Detect: ON" -> covering a key with your hand sends that key to the PC; uncovering releases it.
 *  Tap a key box any time to rename it (empty = ignore this key).
 */
class MainActivity : AppCompatActivity() {
    private lateinit var previewView: PreviewView
    private lateinit var overlay: KeyOverlay
    private lateinit var status: TextView
    private lateinit var ipInput: EditText
    private lateinit var tokenInput: EditText
    private lateinit var detectBtn: Button
    private lateinit var scanBtn: Button
    private lateinit var flipBtn: Button

    private val cameraExecutor = Executors.newSingleThreadExecutor()
    private val ui = Handler(Looper.getMainLooper())

    @Volatile private var layout: KeyboardCore.Layout? = null
    @Volatile private var locked = false
    @Volatile private var scanning = true
    @Volatile private var flip = false
    @Volatile private var detecting = false
    @Volatile private var baselineReady = false
    @Volatile private var baselineAtMs = 0L
    @Volatile private var sensitivity = 0.5f
    private var lastScanMs = 0L
    private var lastCountdown = -1
    private var missCount = 0
    private var socket: WebSocketClient? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN)
        buildUi()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startCamera()
        } else {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), 10)
        }
    }

    // ------------------------------------------------------------------ UI
    private fun buildUi() {
        val prefs = getSharedPreferences("camerakey", MODE_PRIVATE)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(244, 247, 251)) }

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(8, 4, 8, 4)
        }
        ipInput = EditText(this).apply { hint = "PC IP"; setSingleLine(); textSize = 12f; setText(prefs.getString("ip", "192.168.1.10")) }
        tokenInput = EditText(this).apply { hint = "Token"; setSingleLine(); textSize = 12f; setText(prefs.getString("token", "")) }
        controls.addView(ipInput, LinearLayout.LayoutParams(dp(130), dp(44)))
        controls.addView(tokenInput, LinearLayout.LayoutParams(dp(110), dp(44)))
        controls.addView(makeButton("Connect") { connectSocket() })
        controls.addView(makeButton("Test W") { testKey() })
        scanBtn = makeButton("Scan: ON") {
            scanning = !scanning
            if (scanning) { unlockAll() }
            scanBtn.text = if (scanning) "Scan: ON" else "Scan: OFF"
            setStatus(if (scanning) "Scanning for keyboard…" else "Scan paused")
        }
        controls.addView(scanBtn)
        controls.addView(makeButton("Lock + baseline") {
            if (layout == null) {
                setStatus("No keyboard found yet - aim the camera so the whole keyboard is visible")
            } else {
                detecting = false; detectBtn.text = "Detect: OFF"
                baselineReady = false
                baselineAtMs = SystemClock.elapsedRealtime() + 3000
                lastCountdown = -1
                setStatus("Move your hands away… capturing in 3 s")
            }
        })
        detectBtn = makeButton("Detect: OFF") {
            if (!baselineReady) {
                setStatus("Press 'Lock + baseline' first")
            } else {
                detecting = !detecting
                if (!detecting) releaseAllKeys()
                detectBtn.text = if (detecting) "Detect: ON" else "Detect: OFF"
                setStatus(if (detecting) "Detection running - cover a key to type it" else "Detection paused")
            }
        }
        controls.addView(detectBtn)
        flipBtn = makeButton("Upside-down: OFF") {
            flip = !flip
            flipBtn.text = if (flip) "Upside-down: ON" else "Upside-down: OFF"
            layout?.let { KeyboardCore.assignLabels(it, flip); overlay.postInvalidate() }
        }
        controls.addView(flipBtn)
        controls.addView(TextView(this).apply { text = " Sens"; textSize = 11f; setTextColor(Color.DKGRAY) })
        controls.addView(SeekBar(this).apply {
            max = 100; progress = 50
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) { sensitivity = p / 100f }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }, LinearLayout.LayoutParams(dp(110), dp(44)))
        controls.addView(makeButton("Clear") { releaseAllKeys(); unlockAll(); layout = null; overlay.postInvalidate(); setStatus("Cleared") })
        val scroller = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(controls) }
        root.addView(scroller, LinearLayout.LayoutParams(-1, dp(52)))

        status = TextView(this).apply { text = "Starting camera…"; textSize = 12f; setTextColor(Color.DKGRAY); setPadding(dp(10), 0, dp(10), 0) }
        root.addView(status, LinearLayout.LayoutParams(-1, dp(22)))

        val cameraFrame = FrameLayout(this)
        previewView = PreviewView(this).apply {
            scaleType = PreviewView.ScaleType.FIT_CENTER
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        }
        overlay = KeyOverlay()
        cameraFrame.addView(previewView, FrameLayout.LayoutParams(-1, -1))
        cameraFrame.addView(overlay, FrameLayout.LayoutParams(-1, -1))
        root.addView(cameraFrame, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun makeButton(label: String, action: (View) -> Unit): Button = Button(this).apply {
        text = label; textSize = 10f; isAllCaps = false; setPadding(dp(6), 0, dp(6), 0)
        setOnClickListener(action)
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun setStatus(message: String) { runOnUiThread { if (::status.isInitialized) status.text = message } }

    private fun unlockAll() {
        releaseAllKeys()
        locked = false; baselineReady = false; detecting = false; baselineAtMs = 0L
        if (::detectBtn.isInitialized) detectBtn.text = "Detect: OFF"
    }

    // -------------------------------------------------------------- camera
    private fun startCamera() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            val provider = providerFuture.get()
            val aspect = AspectRatioStrategy.RATIO_16_9_FALLBACK_AUTO_STRATEGY
            // Preview and analysis use the SAME 16:9 field of view, so the outline lines up with what you see.
            val previewSelector = ResolutionSelector.Builder().setAspectRatioStrategy(aspect).build()
            val analysisSelector = ResolutionSelector.Builder()
                .setAspectRatioStrategy(aspect)
                .setResolutionStrategy(ResolutionStrategy(Size(1280, 720), ResolutionStrategy.FALLBACK_RULE_CLOSEST_HIGHER_THEN_LOWER))
                .build()
            val preview = Preview.Builder().setResolutionSelector(previewSelector).build()
                .also { it.setSurfaceProvider(previewView.surfaceProvider) }
            val analysis = ImageAnalysis.Builder()
                .setResolutionSelector(analysisSelector)
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_YUV_420_888)
                .build()
            analysis.setAnalyzer(cameraExecutor) { image -> analyzeFrame(image) }
            try {
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
                setStatus("Camera ready · aim at the keyboard, outlines appear automatically")
            } catch (e: Exception) { setStatus("Camera error: ${e.message}") }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun analyzeFrame(image: ImageProxy) {
        try {
            val plane = image.planes[0]
            val buf = plane.buffer
            val w = image.width
            val h = image.height
            val rowStride = plane.rowStride
            val y = ByteArray(w * h)
            if (rowStride == w && plane.pixelStride == 1) {
                buf.rewind(); buf.get(y, 0, w * h)
            } else {
                for (row in 0 until h) { buf.position(row * rowStride); buf.get(y, row * w, w) }
            }
            val frame = KeyboardCore.prepare(y, w, h, image.imageInfo.rotationDegrees, KeyboardCore.WORK_WIDTH)
            val now = SystemClock.elapsedRealtime()

            // 1) scheduled baseline capture
            if (baselineAtMs > 0L) {
                val left = baselineAtMs - now
                if (left > 0) {
                    val sec = (left / 1000 + 1).toInt()
                    if (sec != lastCountdown) { lastCountdown = sec; setStatus("Keep hands away… capturing in $sec s") }
                } else {
                    val l = layout
                    baselineAtMs = 0L
                    if (l != null && l.w == frame.w && l.h == frame.h) {
                        KeyboardCore.captureBaseline(frame.data, frame.w, frame.h, l.keys)
                        locked = true; baselineReady = true
                        val tracked = l.keys.count { it.tracked() }
                        setStatus("Locked · $tracked keys labelled of ${l.keys.size}. Tap a box to rename, then press Detect: ON")
                        overlay.postInvalidate()
                    } else setStatus("Baseline failed (keyboard lost) - try again")
                }
            }

            // 2) live keyboard / key outline scan
            if (scanning && !locked && now - lastScanMs > 300) {
                lastScanMs = now
                val found = KeyboardCore.detectLayout(frame.data, frame.w, frame.h)
                if (found != null && found.keys.size >= 20) {
                    KeyboardCore.assignLabels(found, flip)
                    layout = found
                    missCount = 0
                    val tracked = found.keys.count { it.tracked() }
                    setStatus("Keyboard found · ${found.keys.size} keys, $tracked labelled · tilt ${"%.1f".format(found.angleDeg)}°")
                } else {
                    missCount++
                    if (missCount > 6) { layout = null; setStatus("No keyboard found - show the whole keyboard, even light, avoid glare") }
                }
                overlay.postInvalidate()
            }

            // 3) key press detection
            if (detecting && baselineReady) {
                val l = layout
                if (l != null && l.w == frame.w && l.h == frame.h) {
                    val changed = KeyboardCore.update(frame.data, frame.w, frame.h, l.keys, sensitivity)
                    if (changed.isNotEmpty()) {
                        for (k in changed) sendKey(k.label, k.pressed)
                        overlay.postInvalidate()
                    }
                }
            }
        } catch (e: Exception) {
            setStatus("Frame error: ${e.message}")
        } finally { image.close() }
    }

    // ------------------------------------------------------------- network
    private fun connectSocket() {
        try {
            socket?.close()
            val host = ipInput.text.toString().trim()
            val token = tokenInput.text.toString()
            getSharedPreferences("camerakey", MODE_PRIVATE).edit().putString("ip", host).putString("token", token).apply()
            val client = object : WebSocketClient(URI("ws://$host:8765")) {
                override fun onOpen(handshakedata: ServerHandshake?) {
                    send(JSONObject().put("type", "auth").put("token", token).toString())
                    setStatus("Connected · authenticating…")
                }
                override fun onMessage(message: String?) {
                    val msg = message ?: return
                    try {
                        val j = JSONObject(msg)
                        if (j.has("status")) setStatus("Connected · PC ready (${j.optString("backend")})")
                        else if (j.has("error")) setStatus("PC says: ${j.getString("error")}")
                    } catch (_: Exception) { setStatus(msg.take(70)) }
                }
                override fun onClose(code: Int, reason: String?, remote: Boolean) { setStatus("Disconnected: ${reason ?: code}") }
                override fun onError(ex: Exception?) { setStatus("Wi-Fi error: ${ex?.message}") }
            }
            socket = client
            client.connectionLostTimeout = 20
            client.connect()
            setStatus("Connecting to $host…")
        } catch (e: Exception) { setStatus("Connection error: ${e.message}") }
    }

    private fun sendKey(label: String, down: Boolean) {
        val client = socket
        if (client?.isOpen == true) {
            try { client.send(JSONObject().put("type", "key").put("key", label).put("down", down).toString()) }
            catch (_: Exception) { setStatus("Could not send key event") }
        } else setStatus("Not connected to the PC - press Connect")
    }

    private fun testKey() {
        sendKey("W", true)
        ui.postDelayed({ sendKey("W", false) }, 120)
        setStatus("Sent test key W - it should appear on the PC")
    }

    private fun releaseAllKeys() {
        layout?.keys?.filter { it.pressed }?.forEach { it.pressed = false; sendKey(it.label, false) }
    }

    // ------------------------------------------------------------- overlay
    private fun fittedRect(iw: Int, ih: Int): RectF {
        val vw = overlay.width.toFloat(); val vh = overlay.height.toFloat()
        val scale = minOf(vw / iw, vh / ih)
        val w = iw * scale; val h = ih * scale
        return RectF((vw - w) / 2f, (vh - h) / 2f, (vw + w) / 2f, (vh + h) / 2f)
    }

    private inner class KeyOverlay : View(this@MainActivity) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val path = Path()

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val l = layout ?: return
            val rect = fittedRect(l.w, l.h)
            val sx = rect.width() / l.w
            val sy = rect.height() / l.h
            // keyboard outline
            if (l.hullX.size >= 3) {
                path.reset()
                path.moveTo(rect.left + l.hullX[0] * sx, rect.top + l.hullY[0] * sy)
                for (i in 1 until l.hullX.size) path.lineTo(rect.left + l.hullX[i] * sx, rect.top + l.hullY[i] * sy)
                path.close()
                paint.style = Paint.Style.STROKE; paint.strokeWidth = 4f; paint.color = Color.rgb(255, 200, 0)
                canvas.drawPath(path, paint)
            }
            // every key
            for (k in l.keys) {
                val r = RectF(rect.left + k.x1 * sx, rect.top + k.y1 * sy, rect.left + k.x2 * sx, rect.top + k.y2 * sy)
                if (k.pressed) {
                    paint.style = Paint.Style.FILL; paint.color = Color.argb(140, 30, 200, 90)
                    canvas.drawRect(r, paint)
                }
                paint.style = Paint.Style.STROKE; paint.strokeWidth = 2.5f
                paint.color = if (k.tracked()) Color.rgb(30, 130, 255) else Color.rgb(255, 140, 0)
                canvas.drawRect(r, paint)
                if (k.tracked()) {
                    paint.style = Paint.Style.FILL; paint.color = Color.rgb(0, 60, 160)
                    paint.textAlign = Paint.Align.CENTER
                    paint.textSize = maxOf(10f, minOf(r.height() * 0.45f, r.width() * 0.45f))
                    canvas.drawText(k.label.take(4), r.centerX(), r.centerY() + paint.textSize / 3f, paint)
                }
            }
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            val l = layout ?: return false
            if (e.action == MotionEvent.ACTION_DOWN) return true
            if (e.action == MotionEvent.ACTION_UP) {
                val rect = fittedRect(l.w, l.h)
                val fx = (e.x - rect.left) / (rect.width() / l.w)
                val fy = (e.y - rect.top) / (rect.height() / l.h)
                val hit = l.keys.firstOrNull { fx >= it.x1 && fx <= it.x2 && fy >= it.y1 && fy <= it.y2 }
                if (hit != null) askKeyLabel(hit)
                return true
            }
            return false
        }
    }

    private fun askKeyLabel(key: KeyboardCore.Key) {
        val input = EditText(this).apply {
            hint = "A, 5, SPACE, ENTER, LSHIFT… (empty = ignore)"
            setSingleLine()
            filters = arrayOf(InputFilter.LengthFilter(12))
            setText(if (key.tracked()) key.label else "")
        }
        AlertDialog.Builder(this)
            .setTitle("Key label")
            .setView(input)
            .setPositiveButton("OK") { _, _ ->
                if (key.pressed) { key.pressed = false; sendKey(key.label, false) }
                val t = input.text.toString().trim().uppercase()
                key.label = if (t.isEmpty()) "?" else t
                overlay.postInvalidate()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 10 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) startCamera()
        else setStatus("Camera permission is required")
    }

    override fun onDestroy() {
        detecting = false
        releaseAllKeys()
        socket?.close()
        cameraExecutor.shutdown()
        super.onDestroy()
    }
}
