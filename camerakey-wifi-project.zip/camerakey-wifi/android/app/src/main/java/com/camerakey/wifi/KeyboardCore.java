package com.camerakey.wifi;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Pure-Java vision core (no Android classes) so it can be unit-tested on a PC.
 *  1. prepare()        : Y plane -> small upright grayscale frame
 *  2. detectLayout()   : finds every keycap (white blobs separated by dark gaps)
 *  3. assignLabels()   : guesses QWERTY labels from the row/column structure
 *  4. captureBaseline()/update() : decides which keys are covered by a hand
 */
public final class KeyboardCore {
    private KeyboardCore() {}

    public static final int WORK_WIDTH = 640;
    private static final float VALLEY_THRESHOLD = 8f;
    private static final int SAMPLES = 8; // SAMPLES x SAMPLES grid per key

    // ------------------------------------------------------------------ types
    public static final class Frame {
        public final byte[] data; public final int w, h;
        public Frame(byte[] d, int w, int h) { this.data = d; this.w = w; this.h = h; }
    }

    public static final class Key {
        public int x1, y1, x2, y2;           // bounding box in work-frame pixels
        public float cx, cy;
        public volatile String label = "?";
        public volatile boolean pressed = false;
        float[] base; float baseMean, baseStd;
        int streak;
        public float lastFrac, lastNcc;      // debugging / tuning
        public boolean tracked() { return !"?".equals(label); }
    }

    public static final class Layout {
        public final List<Key> keys = new ArrayList<>();
        public int[] hullX = new int[0], hullY = new int[0];
        public float angleDeg;
        public int w, h;
    }

    // ---------------------------------------------------------------- prepare
    /** src = Y plane (unsigned bytes, row stride already removed), rotation = clockwise degrees to make it upright. */
    public static Frame prepare(byte[] src, int sw, int sh, int rotation, int targetW) {
        int f = Math.max(1, Math.round((float) (rotation % 180 == 0 ? sw : sh) / targetW));
        int dw = sw / f, dh = sh / f;
        byte[] small = new byte[dw * dh];
        int area = f * f;
        for (int y = 0; y < dh; y++) {
            for (int x = 0; x < dw; x++) {
                int s = 0;
                for (int j = 0; j < f; j++) {
                    int row = (y * f + j) * sw + x * f;
                    for (int i = 0; i < f; i++) s += src[row + i] & 0xff;
                }
                small[y * dw + x] = (byte) (s / area);
            }
        }
        int rot = ((rotation % 360) + 360) % 360;
        if (rot == 0) return new Frame(small, dw, dh);
        int ow = (rot == 180) ? dw : dh, oh = (rot == 180) ? dh : dw;
        byte[] out = new byte[ow * oh];
        for (int y = 0; y < dh; y++) {
            for (int x = 0; x < dw; x++) {
                int nx, ny;
                if (rot == 90) { nx = dh - 1 - y; ny = x; }
                else if (rot == 180) { nx = dw - 1 - x; ny = dh - 1 - y; }
                else { nx = y; ny = dw - 1 - x; }
                out[ny * ow + nx] = small[y * dw + x];
            }
        }
        return new Frame(out, ow, oh);
    }

    // ------------------------------------------------------------- detection
    public static Layout detectLayout(byte[] g, int w, int h) {
        // Gap detection: the thin dark lines between keycaps are "valleys" (darker than pixels 2-4 px either side).
        float[] sm = new float[w * h];
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                float acc = 0; int cnt = 0;
                for (int dy = -1; dy <= 1; dy++) {
                    int yy = y + dy; if (yy < 0 || yy >= h) continue;
                    for (int dx = -1; dx <= 1; dx++) {
                        int xx = x + dx; if (xx < 0 || xx >= w) continue;
                        acc += g[yy * w + xx] & 0xff; cnt++;
                    }
                }
                sm[y * w + x] = acc / cnt;
            }
        }
        boolean[] mask = new boolean[w * h];
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                float c0 = sm[y * w + x], best = 0;
                for (int d = 2; d <= 4; d++) {
                    if (x - d >= 0 && x + d < w) best = Math.max(best, 0.5f * (sm[y * w + x - d] + sm[y * w + x + d]) - c0);
                    if (y - d >= 0 && y + d < h) best = Math.max(best, 0.5f * (sm[(y - d) * w + x] + sm[(y + d) * w + x]) - c0);
                }
                mask[y * w + x] = best <= VALLEY_THRESHOLD;   // true = keycap pixel
            }
        }
        boolean[] seen = new boolean[w * h];
        int[] queue = new int[w * h];
        int minArea = Math.max(40, (int) (w * h * 0.0003f));
        List<int[]> comps = new ArrayList<>(); // x1,y1,x2,y2,area
        for (int sy = 0; sy < h; sy++) {
            for (int sx = 0; sx < w; sx++) {
                int si = sy * w + sx;
                if (!mask[si] || seen[si]) continue;
                int head = 0, tail = 0;
                queue[tail++] = si; seen[si] = true;
                int minx = sx, maxx = sx, miny = sy, maxy = sy; int area = 0; long sum = 0;
                while (head < tail) {
                    int p = queue[head++];
                    int cx = p % w, cy = p / w;
                    area++; sum += g[p] & 0xff;
                    if (cx < minx) minx = cx; if (cx > maxx) maxx = cx;
                    if (cy < miny) miny = cy; if (cy > maxy) maxy = cy;
                    if (cx + 1 < w && mask[p + 1] && !seen[p + 1]) { seen[p + 1] = true; queue[tail++] = p + 1; }
                    if (cx > 0 && mask[p - 1] && !seen[p - 1]) { seen[p - 1] = true; queue[tail++] = p - 1; }
                    if (cy + 1 < h && mask[p + w] && !seen[p + w]) { seen[p + w] = true; queue[tail++] = p + w; }
                    if (cy > 0 && mask[p - w] && !seen[p - w]) { seen[p - w] = true; queue[tail++] = p - w; }
                }
                int bw = maxx + 1 - minx, bh = maxy + 1 - miny;
                if (area < minArea || bw < 6 || bh < 6) continue;
                float solidity = (float) area / (bw * bh);
                float minSolidity = ((float) bw / bh > 2.5f) ? 0.35f : 0.55f; // tilted wide keys (space bar) fill less of their box
                if (solidity < minSolidity) continue;
                if (bw > w * 0.5f || bh > h * 0.35f) continue;
                comps.add(new int[]{minx, miny, maxx + 1, maxy + 1, area});
            }
        }
        if (comps.size() < 8) return null;
        List<int[]> sq = new ArrayList<>();
        for (int[] c : comps) {
            float ar = (float) (c[2] - c[0]) / (c[3] - c[1]);
            if (ar >= 0.6f && ar < 1.7f) sq.add(c);
        }
        if (sq.size() < 5) return null;
        int med = medianInt(sq, 4);
        int medW = medianInt(sq, 2, 0);
        List<int[]> kept = new ArrayList<>();
        for (int[] c : comps) if (c[4] >= 0.35f * med && c[4] <= 10f * med) kept.add(c);
        int n = kept.size();
        int[] par = new int[n];
        for (int i = 0; i < n; i++) par[i] = i;
        float d = medW * 0.8f;
        for (int i = 0; i < n; i++) {
            for (int j = i + 1; j < n; j++) {
                int[] a = kept.get(i), b = kept.get(j);
                int dx = Math.max(0, Math.max(a[0], b[0]) - Math.min(a[2], b[2]));
                int dy = Math.max(0, Math.max(a[1], b[1]) - Math.min(a[3], b[3]));
                if (dx <= d && dy <= d) par[find(par, i)] = find(par, j);
            }
        }
        int[] count = new int[n];
        for (int i = 0; i < n; i++) count[find(par, i)]++;
        int best = 0;
        for (int i = 1; i < n; i++) if (count[i] > count[best]) best = i;
        Layout layout = new Layout();
        layout.w = w; layout.h = h;
        for (int i = 0; i < n; i++) {
            if (find(par, i) != find(par, best)) continue;
            int[] c = kept.get(i);
            Key k = new Key();
            k.x1 = c[0]; k.y1 = c[1]; k.x2 = c[2]; k.y2 = c[3];
            k.cx = (c[0] + c[2]) / 2f; k.cy = (c[1] + c[3]) / 2f;
            layout.keys.add(k);
        }
        if (layout.keys.size() < 8) return null;
        buildHull(layout);
        return layout;
    }

    private static long rectSum(long[] integ, int w, int x1, int y1, int x2, int y2) {
        int s = w + 1;
        return integ[y2 * s + x2] - integ[y1 * s + x2] - integ[y2 * s + x1] + integ[y1 * s + x1];
    }
    private static int find(int[] p, int a) { while (p[a] != a) { p[a] = p[p[a]]; a = p[a]; } return a; }
    private static int medianInt(List<int[]> l, int idx) {
        int[] v = new int[l.size()];
        for (int i = 0; i < v.length; i++) v[i] = l.get(i)[idx];
        Arrays.sort(v); return v[v.length / 2];
    }
    /** median of (c[a]-c[b]) */
    private static int medianInt(List<int[]> l, int a, int b) {
        int[] v = new int[l.size()];
        for (int i = 0; i < v.length; i++) v[i] = l.get(i)[a] - l.get(i)[b];
        Arrays.sort(v); return v[v.length / 2];
    }

    private static void buildHull(Layout L) {
        List<int[]> pts = new ArrayList<>();
        for (Key k : L.keys) {
            pts.add(new int[]{k.x1, k.y1}); pts.add(new int[]{k.x2, k.y1});
            pts.add(new int[]{k.x1, k.y2}); pts.add(new int[]{k.x2, k.y2});
        }
        Collections.sort(pts, new Comparator<int[]>() {
            public int compare(int[] a, int[] b) { return a[0] != b[0] ? Integer.compare(a[0], b[0]) : Integer.compare(a[1], b[1]); }
        });
        int n = pts.size();
        int[][] hull = new int[2 * n][];
        int k = 0;
        for (int i = 0; i < n; i++) {
            while (k >= 2 && cross(hull[k - 2], hull[k - 1], pts.get(i)) <= 0) k--;
            hull[k++] = pts.get(i);
        }
        for (int i = n - 2, t = k + 1; i >= 0; i--) {
            while (k >= t && cross(hull[k - 2], hull[k - 1], pts.get(i)) <= 0) k--;
            hull[k++] = pts.get(i);
        }
        k = Math.max(1, k - 1);
        L.hullX = new int[k]; L.hullY = new int[k];
        for (int i = 0; i < k; i++) { L.hullX[i] = hull[i][0]; L.hullY[i] = hull[i][1]; }
    }
    private static long cross(int[] o, int[] a, int[] b) {
        return (long) (a[0] - o[0]) * (b[1] - o[1]) - (long) (a[1] - o[1]) * (b[0] - o[0]);
    }

    // -------------------------------------------------------------- labeling
    private static final String[][] TEMPLATES = {
        /* level 0: space row handled separately */ {},
        /* 1 */ {"LSHIFT:2.25","Z","X","C","V","B","N","M",",",".","/","RSHIFT:2.75"},
        /* 2 */ {"CAPSLOCK:1.75","A","S","D","F","G","H","J","K","L",";","'","ENTER:2.25"},
        /* 3 */ {"TAB:1.5","Q","W","E","R","T","Y","U","I","O","P","[","]","\\:1.5"},
        /* 4 */ {"`","1","2","3","4","5","6","7","8","9","0","-","=","BACKSPACE:2"},
        /* 5 */ {"ESC","F1","F2","F3","F4","F5","F6","F7","F8","F9","F10","F11","F12","DELETE"},
    };

    /** Guess labels for a standard ANSI QWERTY laptop. Keys that cannot be matched stay "?". */
    public static void assignLabels(Layout L, boolean upsideDown) {
        List<Key> keys = L.keys;
        for (Key k : keys) k.label = "?";
        int n = keys.size();
        if (n < 8) return;
        float[] ws = new float[n], hs = new float[n];
        int m = 0;
        for (Key k : keys) {
            float bw = k.x2 - k.x1, bh = k.y2 - k.y1, ar = bw / bh;
            if (ar >= 0.6f && ar < 1.7f) { ws[m] = bw; hs[m] = bh; m++; }
        }
        if (m < 4) return;
        float[] w2 = Arrays.copyOf(ws, m), h2 = Arrays.copyOf(hs, m);
        Arrays.sort(w2); Arrays.sort(h2);
        float medW = w2[m / 2], medH = h2[m / 2];

        // 1) keyboard tilt = rotation that makes the rows most "peaky"
        float bestScore = -1, bestAngle = 0;
        float bin = Math.max(2f, medH * 0.5f);
        for (float a = -25f; a <= 25f; a += 0.5f) {
            double rad = Math.toRadians(a), s = Math.sin(rad), c = Math.cos(rad);
            float[] yp = new float[n]; float mn = Float.MAX_VALUE;
            for (int i = 0; i < n; i++) { yp[i] = (float) (-keys.get(i).cx * s + keys.get(i).cy * c); mn = Math.min(mn, yp[i]); }
            int[] hist = new int[(int) ((L.h + L.w) / bin) + 4];
            for (int i = 0; i < n; i++) hist[(int) ((yp[i] - mn) / bin)]++;
            float score = 0; for (int v : hist) score += (float) v * v;
            if (score > bestScore) { bestScore = score; bestAngle = a; }
        }
        L.angleDeg = bestAngle;
        double rad = Math.toRadians(bestAngle), s = Math.sin(rad), c = Math.cos(rad);
        final float[] xp = new float[n], yp = new float[n];
        for (int i = 0; i < n; i++) {
            Key k = keys.get(i);
            xp[i] = (float) (k.cx * c + k.cy * s);
            yp[i] = (float) (-k.cx * s + k.cy * c);
            if (upsideDown) { xp[i] = -xp[i]; yp[i] = -yp[i]; }
        }
        // 2) rows
        Integer[] order = new Integer[n];
        for (int i = 0; i < n; i++) order[i] = i;
        final float[] ypf = yp, xpf = xp;
        Arrays.sort(order, new Comparator<Integer>() {
            public int compare(Integer a, Integer b) { return Float.compare(ypf[a], ypf[b]); }
        });
        List<List<Integer>> rows = new ArrayList<>();
        List<Integer> cur = new ArrayList<>();
        for (int idx = 0; idx < n; idx++) {
            int i = order[idx];
            if (!cur.isEmpty() && yp[i] - yp[cur.get(cur.size() - 1)] > medH * 0.5f) { rows.add(cur); cur = new ArrayList<>(); }
            cur.add(i);
        }
        rows.add(cur);
        for (List<Integer> row : rows) {
            Collections.sort(row, new Comparator<Integer>() {
                public int compare(Integer a, Integer b) { return Float.compare(xpf[a], xpf[b]); }
            });
        }
        // key pitch along the row direction = typical spacing between neighbouring keys
        List<Float> gaps = new ArrayList<>();
        for (List<Integer> row : rows)
            for (int j = 0; j + 1 < row.size(); j++) {
                float gp = xp[row.get(j + 1)] - xp[row.get(j)];
                if (gp > 0.5f * medW && gp < 1.5f * medW) gaps.add(gp);
            }
        Collections.sort(gaps);
        float pitchPx = gaps.size() >= 5 ? gaps.get(gaps.size() / 2) : medW;
        // 3) find the space bar (very wide key); then try the plausible anchors and keep the one that labels most keys
        int spaceRow = -1, spaceKey = -1; float widest = 0;
        for (int r = 0; r < rows.size(); r++) {
            for (int i : rows.get(r)) {
                float bw = keys.get(i).x2 - keys.get(i).x1;
                if (bw > 3.2f * medW && bw > widest) { widest = bw; spaceRow = r; spaceKey = i; }
            }
        }
        List<Integer> anchors = new ArrayList<>();
        if (spaceRow >= 0) {
            anchors.add(spaceRow - 1);  // space bar seen: the row above it is the Z row
        } else {
            anchors.add(rows.size() - 1);   // last row is the Z row (space bar not seen)
            anchors.add(rows.size() - 2);   // last row is the space row
        }
        int bestAnchor = -1, bestCount = -1;
        for (int zRow : anchors) {
            if (zRow < 0) continue;
            int cnt = labelAll(keys, rows, xp, zRow, spaceKey, pitchPx);
            if (cnt > bestCount) { bestCount = cnt; bestAnchor = zRow; }
        }
        if (bestAnchor >= 0) labelAll(keys, rows, xp, bestAnchor, spaceKey, pitchPx);
        else for (Key k : keys) k.label = "?";
    }

    private static int labelAll(List<Key> keys, List<List<Integer>> rows, float[] xp, int zRow, int spaceKey, float pitchPx) {
        for (Key k : keys) k.label = "?";
        if (spaceKey >= 0) keys.get(spaceKey).label = "SPACE";
        for (int level = 1; level <= 5; level++) {
            int r = zRow - (level - 1);
            if (r < 0) break;
            labelRow(keys, rows.get(r), xp, TEMPLATES[level], pitchPx);
        }
        int cnt = 0;
        for (Key k : keys) if (k.tracked()) cnt++;
        return cnt;
    }

    private static void labelRow(List<Key> keys, List<Integer> row, float[] xp, String[] tmpl, float unitPx) {
        int tn = tmpl.length;
        if (row.size() < Math.ceil(tn * 0.6)) return;
        String[] names = new String[tn]; float[] wd = new float[tn], center = new float[tn];
        float acc = 0;
        for (int i = 0; i < tn; i++) {
            String[] parts = tmpl[i].split(":(?=[0-9.]+$)");
            names[i] = parts[0]; wd[i] = parts.length > 1 ? Float.parseFloat(parts[1]) : 1f;
            center[i] = acc + wd[i] / 2f; acc += wd[i];
        }
        float x0 = xp[row.get(0)];
        // try every template key as the first detected key, plus small scale changes; keep the best fit
        float bestTotal = Float.MAX_VALUE; int[] match = null; float[] dist = null;
        float[] scales = {0.94f, 0.97f, 1f, 1.03f, 1.06f};
        for (int i0 = 0; i0 < tn; i0++) {
            for (float sc : scales) {
                int[] mm = new int[row.size()]; float[] dd = new float[row.size()]; float total = 0;
                for (int j = 0; j < row.size(); j++) {
                    float u = center[i0] + (xp[row.get(j)] - x0) / (unitPx * sc);
                    int bi = 0; float bd = Float.MAX_VALUE;
                    for (int i = 0; i < tn; i++) { float d2 = Math.abs(u - center[i]); if (d2 < bd) { bd = d2; bi = i; } }
                    mm[j] = bi; dd[j] = Math.min(bd, 1.5f); total += dd[j];
                }
                if (total < bestTotal) { bestTotal = total; match = mm; dist = dd; }
            }
        }
        if (match == null || bestTotal / row.size() > 0.3f) return; // structure does not look like this row
        float[] bestD = new float[tn]; Arrays.fill(bestD, Float.MAX_VALUE); int[] owner = new int[tn]; Arrays.fill(owner, -1);
        for (int j = 0; j < row.size(); j++) {
            if (dist[j] < 0.45f && dist[j] < bestD[match[j]]) { bestD[match[j]] = dist[j]; owner[match[j]] = j; }
        }
        for (int i = 0; i < tn; i++) if (owner[i] >= 0) keys.get(row.get(owner[i])).label = names[i];
    }

    // --------------------------------------------------------------- pressing
    private static float[] sample(byte[] g, int w, int h, Key k) {
        float[] out = new float[SAMPLES * SAMPLES];
        float bw = k.x2 - k.x1, bh = k.y2 - k.y1;
        float ix = k.x1 + bw * 0.2f, iy = k.y1 + bh * 0.2f, iw = bw * 0.6f, ih = bh * 0.6f;
        for (int j = 0; j < SAMPLES; j++) {
            int y = Math.min(h - 1, Math.max(0, Math.round(iy + (j + 0.5f) / SAMPLES * ih)));
            for (int i = 0; i < SAMPLES; i++) {
                int x = Math.min(w - 1, Math.max(0, Math.round(ix + (i + 0.5f) / SAMPLES * iw)));
                out[j * SAMPLES + i] = g[y * w + x] & 0xff;
            }
        }
        return out;
    }
    private static float mean(float[] a) { float s = 0; for (float v : a) s += v; return s / a.length; }
    private static float std(float[] a, float m) { float s = 0; for (float v : a) s += (v - m) * (v - m); return (float) Math.sqrt(s / a.length); }

    public static void captureBaseline(byte[] g, int w, int h, List<Key> keys) {
        for (Key k : keys) {
            k.base = sample(g, w, h, k);
            k.baseMean = mean(k.base); k.baseStd = std(k.base, k.baseMean);
            k.pressed = false; k.streak = 0;
        }
    }

    /**
     * @param sensitivity 0..1 (higher = reacts to smaller cover)
     * @return keys whose pressed state changed on this frame
     */
    public static List<Key> update(byte[] g, int w, int h, List<Key> keys, float sensitivity) {
        List<Key> changed = new ArrayList<>();
        int n = keys.size();
        float[][] cur = new float[n][];
        List<Float> ratios = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            Key k = keys.get(i);
            if (k.base == null) continue;
            cur[i] = sample(g, w, h, k);
            if (k.baseMean > 40f) ratios.add(mean(cur[i]) / k.baseMean);
        }
        // local brightness compensation: median ratio of nearby keys (handles shadows over part of the keyboard)
        float[] gains = new float[n];
        float pitch = 1f;
        { List<Float> pw = new ArrayList<>(); for (Key k : keys) pw.add((float) (k.x2 - k.x1)); Collections.sort(pw); pitch = pw.get(pw.size() / 2); }
        float radius = pitch * 4f;
        float[] ratio = new float[n];
        boolean[] hasRatio = new boolean[n];
        for (int i = 0; i < n; i++) {
            Key k = keys.get(i);
            if (cur[i] != null && k.baseMean > 40f) { ratio[i] = mean(cur[i]) / k.baseMean; hasRatio[i] = true; }
        }
        for (int i = 0; i < n; i++) {
            List<Float> near = new ArrayList<>();
            for (int j = 0; j < n; j++) {
                if (!hasRatio[j]) continue;
                float dx = keys.get(j).cx - keys.get(i).cx, dy = keys.get(j).cy - keys.get(i).cy;
                if (dx * dx + dy * dy <= radius * radius) near.add(ratio[j]);
            }
            float gv = 1f;
            if (near.size() >= 5) { Collections.sort(near); gv = near.get(near.size() / 2); }
            gains[i] = Math.max(0.5f, Math.min(1.7f, gv));
        }
        float diffThr = 55f - 30f * sensitivity;
        float pressFrac = 0.65f - 0.25f * sensitivity;
        for (int i = 0; i < n; i++) {
            Key k = keys.get(i);
            if (k.base == null || cur[i] == null || !k.tracked()) continue;
            float[] c = cur[i];
            int cnt = 0;
            for (int p = 0; p < c.length; p++) { c[p] /= gains[i]; if (Math.abs(c[p] - k.base[p]) > diffThr) cnt++; }
            float frac = (float) cnt / c.length;
            float cm = mean(c), cs = std(c, cm);
            float ncc = Float.NaN;
            if (k.baseStd > 8f) {
                if (cs < 2f) ncc = 0f;
                else {
                    float num = 0; for (int p = 0; p < c.length; p++) num += (c[p] - cm) * (k.base[p] - k.baseMean);
                    ncc = num / (c.length * cs * k.baseStd);
                }
            }
            k.lastFrac = frac; k.lastNcc = ncc;
            boolean wantPressed = k.pressed;
            if (!k.pressed) {
                if (frac > pressFrac || (!Float.isNaN(ncc) && ncc < 0.25f && frac > 0.3f)) wantPressed = true;
            } else {
                if (frac < 0.25f && (Float.isNaN(ncc) || ncc > 0.55f)) wantPressed = false;
            }
            if (wantPressed != k.pressed) {
                if (++k.streak >= 2) { k.pressed = wantPressed; k.streak = 0; changed.add(k); }
            } else k.streak = 0;
        }
        return changed;
    }
}
