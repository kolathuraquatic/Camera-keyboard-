# CameraKey WiFi

Use an Android phone camera as a keyboard reader. Point it at a real (even dead) laptop keyboard: when a key is
**visible** nothing happens, when it is **covered by your finger/hand** that key is typed on your PC over Wi-Fi.

## What's new in this version
* **Automatic live keyboard detection** - outline around the whole keyboard and around **every key**, drawn live on the camera view.
* **Auto labels** (QWERTY, tilt-aware, also works upside-down). Tap any box to rename it (empty = ignore that key).
* **Much better press detection** - compares each key with a clean "baseline" picture using texture correlation plus
  local brightness compensation, so shadows and exposure changes do not trigger keys.
* **Linux/Wayland fix** - the receiver now types through a virtual keyboard (`uinput`), which works on Ubuntu's default
  Wayland session in every app. (`pynput` alone only reaches X11 apps - that is why connecting worked but nothing typed.)
* **"Test W" button** to verify the phone -> PC path without using the camera.

## 1. PC (Ubuntu)
```bash
cd pc-receiver
chmod +x run-linux.sh
./run-linux.sh --selftest     # click into a text editor: it must type "work" after 5 s
./run-linux.sh                # normal run: enter a token, note the printed IP
```
`run-linux.sh` asks for sudo once per boot to allow access to `/dev/uinput`. For a permanent setup run
`./setup-linux-permanent.sh` once and log out/in. The receiver prints `Keyboard backend: uinput` when everything is right.
Windows: `run-windows.bat` (unchanged).

## 2. Phone
Build the APK as before (GitHub Actions workflow or Android Studio, `android/` folder) and install it.

1. Phone and PC on the same Wi-Fi. Enter the PC IP + token, tap **Connect** (status: `PC ready (uinput)`).
2. Tap **Test W**. A `w` must appear on the PC. If not, fix the PC side first (see Troubleshooting).
3. Mount the phone firmly above the keyboard in landscape, whole keyboard in view, even lighting, little glare.
   Outlines appear automatically: yellow = keyboard, blue = labelled key, orange = key with unknown label.
4. Check the labels. Tap a wrong box to rename it. Use **Upside-down** if the keyboard is seen rotated 180 degrees.
5. Hands away, tap **Lock + baseline** (3 s countdown) - this freezes the layout and records the clean picture.
6. Tap **Detect: ON**. Cover a key = key down, uncover = key up (green box while pressed). **Sens** slider: higher reacts to smaller coverage.
   Tap **Rescan** by pressing **Scan: ON** again if you move the phone.

## Limits (be aware)
* It sees *covering*, not mechanical pressing: a finger resting/hovering over a key counts. Mount the phone so it looks
  down on the keys, and type with one finger to start with.
* Auto layout assumes a standard ANSI QWERTY laptop (rows: F-row, numbers, QWERTY, ASDF, ZXCV, space). Different layouts: rename keys by tapping.
* Camera must not move after locking. If it moves, rescan and lock again.
* Linux input uses a virtual keyboard device; the token is only a basic LAN check, traffic is not encrypted.

## Troubleshooting
* Nothing typed with **Test W**: the receiver output must show `DOWN W`. If it shows `Keyboard backend: pynput` on Ubuntu, run `./run-linux.sh` again and allow sudo.
* `DOWN W` shows but nothing appears: use `./run-linux.sh --selftest`.
* No outline: make sure the whole keyboard is visible, avoid strong glare, keys should be lighter than the gaps.
* False presses: lock again with hands fully away, lower **Sens**, improve lighting.
* Keys never trigger: raise **Sens**; make sure the key label is not `?`.
